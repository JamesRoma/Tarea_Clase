package Tarea;

import java.util.Scanner;

public class Main {
	// este metodo realiza la operacion del Producto punto
	public static double Producto_punto(double[] A, double[] B) {
        double resultado = 0;
        for (int i = 0; i < A.length; i++) {
            resultado += A[i] * B[i];
        }
        return resultado;
    }
	// aqui demuestra si es falso o verdadero y si son ortogonales
    public static boolean sonOrtogonal(double[] A, double[] B) {
        return Producto_punto(A, B) == 0;
    }
    // da la expresion de z = producto punto / modulo de A y Modulo de B
    public static double zExpression(double[] A, double[] B) {
        double prod_Punt = Producto_punto(A, B);
        double modA = Math.sqrt(Producto_punto(A, A));
        double modB = Math.sqrt(Producto_punto(B, B));
        return prod_Punt / (modA * modB);
    }

	public static void main(String[] args) {
		
		Scanner tecla = new Scanner(System.in);
		
		System.out.println("Ingrese el Tamaño de los Valores en los Arreglos:");
        int n = tecla.nextInt();

        double[] A = new double[n];
        double[] B = new double[n];

        System.out.println("Ingrese los valores del arreglo A:");
        for (int i = 0; i < n; i++) {
            A[i] = tecla.nextDouble();
        }

        System.out.println("Ingrese los valores del arreglo B:");
        for (int i = 0; i < n; i++) {
            B[i] = tecla.nextDouble();
        }
        System.out.println("===========================================");
        System.out.println("Producto de puntos: " + Producto_punto(A, B));
        System.out.println("Son ortogonales y es: " + sonOrtogonal(A, B));
        System.out.println("La Expresion en Z: " + zExpression(A, B));
        System.out.println("===========================================");
    }
        
}